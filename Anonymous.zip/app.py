from flask import Flask, render_template, request, jsonify, url_for
from flask_socketio import SocketIO, send, emit
from threading import Lock
import os
from flask_cors import CORS  # Import Flask-CORS

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})  # Enable CORS for all routes
socketio = SocketIO(app, cors_allowed_origins="*")

clients = 0
typing_users = set()
lock = Lock()

@app.route('/')
def index():
    return render_template('chat.html')

@app.route('/get-emojis')
def get_emojis():
    emoji_dir = os.path.join(app.static_folder, "emojis")  # Dossier où sont stockés les emojis
    emojis = [url_for('static', filename=f"emojis/{img}") for img in os.listdir(emoji_dir) if img.endswith((".png", ".jpg", ".gif"))]
    return jsonify(emojis)  # Retourne la liste des images sous forme de JSON

@socketio.on('connect')
def handle_connect():
    global clients
    with lock:
        clients += 1
    update_status()

@socketio.on('disconnect')
def handle_disconnect():
    global clients
    with lock:
        clients -= 1
        typing_users.discard(request.sid)
    update_status()

@socketio.on('message')
def handle_message(msg):
    # Traitement du message (texte ou image)
    send({
        'username': msg['username'],
        'usercolor': msg['usercolor'],
        'text': msg.get('text', ''),  # Utilise get() avec une valeur par défaut
        'image': msg.get('image', None)  # Si c'est une image, elle est là
    }, broadcast=True)
    # L'utilisateur ne tape plus après avoir envoyé
    with lock:
        if request.sid in typing_users:
            typing_users.remove(request.sid)
    update_status()

@socketio.on('typing')
def handle_typing(is_typing):
    with lock:
        if is_typing:
            typing_users.add(request.sid)
        else:
            typing_users.discard(request.sid)
    update_status()

def update_status():
    with lock:
        if typing_users:
            count = len(typing_users)
            status = f"{count} {'personne écrit' if count == 1 else 'personnes écrivent'}..."
        else:
            status = f"{clients} {'personne connectée' if clients == 1 else 'personnes connectées'}"
    emit('status', status, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True)